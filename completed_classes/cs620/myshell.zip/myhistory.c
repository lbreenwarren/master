/* CS620 2023 Fall: Homework 4
 * File: myhistory.c
 * Author: Bo-Cheng Cui
 * Date: 09/04/2024
 * Desc: This is the skeleton file for myhistory.
 *       You implement the functions in this file.
 *       And feel free to add more functions as you need.
*/

#include "myshell.h"

pid_t childpid;
int status;
char input[MAX_INPUT];
char *args[MAX_ARGS];
char **history;
int next_cmd;

void freeHistory(){
    for (int i = 0; i < 10; ++i) {
        free(history[i]);
    }
}

void initHistory(){
    history = malloc(10 * sizeof(char*));  // Allocate space for 10 char pointers
    if (history == NULL) {
        perror("Failed to allocate memory for history array");
        exit(1);
    }
    next_cmd = 0;
    for (int i = 0; i < 10; ++i) {
        history[i] = malloc(MAX_INPUT);
        if (history[i] == NULL) {
            perror("Failed to allocate memory for history entry");
            exit(1);
        }
    }
}

void print_history(){
    for (int i = 0; i < next_cmd; ++i) {
        printf("%d  %s", i, history[i]);
    }
} 

void add_history() {
    //printf("Test");
    int i = 0;
    while (i < MAX_ARGS && args[i] != NULL) {
        strcat(history[next_cmd], args[i]);
        strcat(history[next_cmd], " ");
        ++i;
    }
    strcat(history[next_cmd], "\n");
    next_cmd = (next_cmd + 1) % 10;
}

void handleInput(){
    
    // get the input from stdin.
    if (fgets(input, MAX_INPUT, stdin) == NULL) {
        perror("Error reading input");
        exit(1);  
    }
}

// feel free to change this function to fit your needs.
void make_args(){
    for (int i = 0; i < MAX_ARGS; i++)
    {
        // first call to strtok must include input
        if (i == 0)
            args[i] = strtok(input, " ,\n");
        // subsequent calls to strtok take NULL
        else
        {
            args[i] = strtok(NULL, " ,\n");
        }
    }
}

int myshell(){
    /*
    *   1. check if the command is EXIT_COMMAND, HISTORY_COMMAND, or contains illegal characters.
    *   2. if it is, handle it and return the status code (EXIT_CODE, HISTORY_CODE, ILL_CHAR_CODE).
    *   3. if not, fork a child process to execute the command, and wait for the child process to finish. 
    *      std functions for fork, execute and wait: fork(), execvp(), wait()
    *   4. return the status code.
    *   
    */

    for(int i = 0; i < MAX_ARGS; ++i) {
        if (args[i] == NULL) {
            break;  // No more arguments to process
        }
        
        if (strcmp(args[i],EXIT_COMMAND) == 0){
                return EXIT_CODE;
            }
        if (atoi(args[i]) == HISTORY_CODE){
            print_history();
            return HISTORY_CODE;
        }
        if ((strcmp(args[i],"|") == 0) || (strcmp(args[i],"*") == 0) || (strcmp(args[i],"<") == 0) || (strcmp(args[i],">") == 0)){
            return ILL_CHAR_CODE;
        }
    }
    
    int status;
    int pid = fork();
    if (pid < 0) {
        perror("Failed to execute fork command");
        exit(1);
    }

    if (pid == 0) {
        execvp(args[0], args);
        perror("Error executing command");
        exit(1);
    } else {
        wait(&status);
        add_history();
    }
    
    return NORMAL_CODE;
}
