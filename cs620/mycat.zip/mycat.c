#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        char str[100];
        fgets(str, sizeof(str), stdin);
        printf("%s", str);
    }
    for (int i = 1; i < argc; ++i) {
        FILE *fp = fopen(argv[i], "r");

        if (fp == NULL) {
        printf("mycat: Could not open file\n");
        return 1;
        }

        char next_char = getc(fp);
        while (next_char != EOF) {
            printf("%c", next_char);
            next_char = getc(fp);
        }
        printf("\n");
    }
}